/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "lcd.h"
#include <stdio.h>

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef struct {
    int16_t temperature;  // Sıcaklık (-30 ile 105 arası)
    uint16_t adc_value;   // ADC değeri
} NTC_LookupEntry;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define NTC_TABLE_SIZE 136
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

TIM_HandleTypeDef htim1;

/* USER CODE BEGIN PV */
uint32_t potValue = 0;
uint32_t ntcValue = 0;
float duty = 0;
float sicaklik = 0;

int mod = 0; // 0: Duty göster, 1: Sıcaklık göster

// NTC 10K Lookup Table (-30°C ile +105°C arası)
const NTC_LookupEntry ntc_table[NTC_TABLE_SIZE] = {
    {-30, 5599}, {-29, 5564}, {-28, 5527}, {-27, 5489}, {-26, 5450},
    {-25, 5408}, {-24, 5365}, {-23, 5321}, {-22, 5274}, {-21, 5227},
    {-20, 5177}, {-19, 5125}, {-18, 5072}, {-17, 5018}, {-16, 4961},
    {-15, 4904}, {-14, 4844}, {-13, 4785}, {-12, 4720}, {-11, 4657},
    {-10, 4593}, {-9, 4528}, {-8, 4457}, {-7, 4390}, {-6, 4319},
    {-5, 4247}, {-4, 4177}, {-3, 4101}, {-2, 4028}, {-1, 3957},
    {0, 3881}, {1, 3800}, {2, 3723}, {3, 3651}, {4, 3576},
    {5, 3495}, {6, 3422}, {7, 3345}, {8, 3264}, {9, 3193},
    {10, 3118}, {11, 3039}, {12, 2956}, {13, 2887}, {14, 2814},
    {15, 2738}, {16, 2659}, {17, 2576}, {18, 2511}, {19, 2444},
    {20, 2375}, {21, 2302}, {22, 2253}, {23, 2176}, {24, 2123},
    {25, 2068}, {26, 2012}, {27, 1955}, {28, 1896}, {29, 1835},
    {30, 1773}, {31, 1741}, {32, 1676}, {33, 1609}, {34, 1574},
    {35, 1539}, {36, 1468}, {37, 1432}, {38, 1395}, {39, 1357},
    {40, 1319}, {41, 1241}, {42, 1201}, {43, 1201}, {44, 1160},
    {45, 1119}, {46, 1077}, {47, 1034}, {48, 991}, {49, 991},
    {50, 946}, {51, 902}, {52, 902}, {53, 856}, {54, 809},
    {55, 809}, {56, 762}, {57, 762}, {58, 714}, {59, 714},
    {60, 665}, {61, 665}, {62, 665}, {63, 615}, {64, 615},
    {65, 564}, {66, 564}, {67, 564}, {68, 512}, {69, 512},
    {70, 512}, {71, 460}, {72, 460}, {73, 460}, {74, 460},
    {75, 406}, {76, 406}, {77, 406}, {78, 406}, {79, 406},
    {80, 351}, {81, 351}, {82, 351}, {83, 295}, {84, 295},
    {85, 295}, {86, 295}, {87, 295}, {88, 239}, {89, 239},
    {90, 239}, {91, 239}, {92, 239}, {93, 239}, {94, 239},
    {95, 239}, {96, 239}, {97, 239}, {98, 239}, {99, 239},
    {100, 181}, {101, 181}, {102, 181}, {103, 181}, {104, 181}, {105, 181}
};

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM1_Init(void);
/* USER CODE BEGIN PFP */
void Display_4Digit(int value);
float NTC_ADC_to_Temperature(uint16_t adc_value);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_TIM1_Init();
  /* USER CODE BEGIN 2 */
  LCD_Init();

  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);

  LCD_Clear();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  // Buton okuma
	  if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_10) == GPIO_PIN_RESET) {
		  HAL_Delay(300); // debounce
		  mod = (mod + 1) % 2;
		  LCD_Clear();
	  }

	  // ADC Start - Potansiyometre okuma (Kanal 0)
	  HAL_ADC_Start(&hadc1);
	  HAL_ADC_PollForConversion(&hadc1, 100);
	  potValue = HAL_ADC_GetValue(&hadc1);

	  // ADC Start - NTC okuma (Kanal 1)
	  HAL_ADC_Start(&hadc1);
	  HAL_ADC_PollForConversion(&hadc1, 100);
	  ntcValue = HAL_ADC_GetValue(&hadc1);

	  // Pot --> PWM duty
	  duty = ((float)potValue / 4095.0f) * 100.0f;
	  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, (uint32_t)((duty / 100.0f) * 65535));

	  // NTC --> Sıcaklık (Lookup table ile)
	  sicaklik = NTC_ADC_to_Temperature(ntcValue);

	  char buffer[16];

	  if (mod == 0) {
		  // Duty LCD'de göster
		  LCD_SetCursor(0, 0);
		  LCD_WriteString("PWM Duty:     ");
		  snprintf(buffer, sizeof(buffer), "%.1f%%      ", duty);
		  LCD_SetCursor(1, 0);
		  LCD_WriteString(buffer);
	  } else {
		  // Sıcaklık LCD'de ve 7 segmentte göster
		  LCD_SetCursor(0, 0);
		  LCD_WriteString("Sicaklik:     ");
		  if (sicaklik == -999.0f) {
		      // Hata durumu
		      LCD_SetCursor(1, 0);
		      LCD_WriteString("HATA!       ");
		      Display_4Digit(9999); // Hata göstergesi
		  } else {
		      snprintf(buffer, sizeof(buffer), "%.1f C      ", sicaklik);
		      LCD_SetCursor(1, 0);
		      LCD_WriteString(buffer);
		      Display_4Digit((int)sicaklik);
		  }
	  }

	  HAL_Delay(200);
  }
  /* USER CODE END 3 */
}

/**
  * @brief NTC ADC değerini sıcaklığa dönüştürür (Lookup table ile interpolasyon)
  * @param adc_value: ADC'den okunan değer (0-4095)
  * @retval Sıcaklık değeri (°C), hata durumunda -999.0
  */
float NTC_ADC_to_Temperature(uint16_t adc_value)
{
    // Aralık kontrolü
    if (adc_value > ntc_table[0].adc_value) {
        return -30.0f; // Minimum sıcaklık
    }
    if (adc_value < ntc_table[NTC_TABLE_SIZE-1].adc_value) {
        return 105.0f; // Maksimum sıcaklık
    }

    // Tabloda arama ve interpolasyon
    for (int i = 0; i < NTC_TABLE_SIZE - 1; i++) {
        if (adc_value <= ntc_table[i].adc_value && adc_value >= ntc_table[i+1].adc_value) {
            // Linear interpolasyon
            float temp_diff = (float)(ntc_table[i+1].temperature - ntc_table[i].temperature);
            float adc_diff = (float)(ntc_table[i].adc_value - ntc_table[i+1].adc_value);
            float adc_offset = (float)(ntc_table[i].adc_value - adc_value);

            float temperature = ntc_table[i].temperature + (temp_diff * adc_offset / adc_diff);
            return temperature;
        }
    }

    return -999.0f; // Hata durumu
}

// 5461BS-1 Display için segment font (Common Cathode)
// PA2=a, PA3=b, PA4=c, PA5=d, PA6=e, PA7=f, PA9=g
const uint8_t segmentMap[10] = {
    0b01111110, // 0: a,b,c,d,e,f
    0b00001100, // 1: b,c
    0b10110110, // 2: a,b,g,e,d
    0b10011110, // 3: a,b,g,c,d
    0b11001100, // 4: f,g,b,c
    0b11011010, // 5: a,f,g,c,d
    0b11111010, // 6: a,f,g,e,d,c
    0b00001110, // 7: a,b,c
    0b11111110, // 8: a,b,c,d,e,f,g
    0b11011110  // 9: a,b,c,d,f,g
};

void Display_4Digit(int value)
{
    // Negatif değerler için mutlak değer al
    int abs_value = (value < 0) ? -value : value;

    int digit[4];
    digit[0] = (abs_value / 1000) % 10;  // En soldaki digit
    digit[1] = (abs_value / 100) % 10;
    digit[2] = (abs_value / 10) % 10;
    digit[3] = abs_value % 10;           // En sağdaki digit

    // Multiplexing için döngü
    for (int repeat = 0; repeat < 50; repeat++) {
        for (int i = 0; i < 4; i++) {
            // Önce tüm COM pinlerini kapat (Common Cathode için HIGH)
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15, GPIO_PIN_SET);

            uint8_t segVal = segmentMap[digit[i]];

            // İlk digit'te negatif işareti göster (sadece orta segment)
            if (i == 0 && value < 0 && digit[0] == 0) {
                segVal = 0b10000000; // Sadece g segmenti (minus işareti)
            }

            // 5461BS-1 pin bağlantıları:
            // PA2=a, PA3=b, PA4=c, PA5=d, PA6=e, PA7=f, PA9=g
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, (segVal >> 1) & 0x01); // a
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, (segVal >> 2) & 0x01); // b
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, (segVal >> 3) & 0x01); // c
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, (segVal >> 4) & 0x01); // d
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, (segVal >> 5) & 0x01); // e
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, (segVal >> 6) & 0x01); // f
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, (segVal >> 7) & 0x01); // g

            // Şimdiki digit'i aktif et (Common Cathode için LOW)
            // 5461BS-1 digit sırası: PB12=Digit1, PB13=Digit2, PB14=Digit3, PB15=Digit4
            switch(i) {
                case 0: HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET); break; // 1. digit
                case 1: HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_RESET); break; // 2. digit
                case 2: HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET); break; // 3. digit
                case 3: HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_RESET); break; // 4. digit
            }

            HAL_Delay(2);
        }
    }

    // Tüm digitleri kapat
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15, GPIO_PIN_SET);
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV16;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{
  ADC_ChannelConfTypeDef sConfig = {0};

  /** ADC1 Genel Ayarlar **/
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = ENABLE;  // Çoklu kanal için ENABLE
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 2;  // 2 kanal kullanılacak
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SEQ_CONV;

  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler(); // Hata varsa burada yakala
  }

  /** Kanal 0 (PA0 - Potansiyometre) **/
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_15CYCLES;

  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Kanal 1 (PA1 - NTC) **/
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = 2;

  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5
                          |GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_12|GPIO_PIN_13
                          |GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_4|GPIO_PIN_5
                          |GPIO_PIN_6|GPIO_PIN_7, GPIO_PIN_SET); // Common Cathode için başlangıçta SET

  /*Configure GPIO pins : PA2 PA3 PA4 PA5
                           PA6 PA7 PA9 */
  GPIO_InitStruct.Pin = GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5
                          |GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB1 PB12 PB13
                           PB14 PB15 PB4 PB5
                           PB6 PB7 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_12|GPIO_PIN_13
                          |GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_4|GPIO_PIN_5
                          |GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PB10 */
  GPIO_InitStruct.Pin = GPIO_PIN_10;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
