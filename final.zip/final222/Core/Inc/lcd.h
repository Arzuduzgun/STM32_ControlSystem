/*
 * lcd.h
 *
 *  Created on: Jun 13, 2025
 *      Author: arzud
 */

#ifndef INC_LCD_H_
#define INC_LCD_H_

#include "stm32f4xx_hal.h"

// LCD Pin Tanımlamaları
#define LCD_RS_GPIO_Port GPIOB
#define LCD_RS_Pin       GPIO_PIN_0

#define LCD_E_GPIO_Port  GPIOB
#define LCD_E_Pin        GPIO_PIN_1

#define LCD_D4_GPIO_Port GPIOB
#define LCD_D4_Pin       GPIO_PIN_4
#define LCD_D5_GPIO_Port GPIOB
#define LCD_D5_Pin       GPIO_PIN_5
#define LCD_D6_GPIO_Port GPIOB
#define LCD_D6_Pin       GPIO_PIN_6
#define LCD_D7_GPIO_Port GPIOB
#define LCD_D7_Pin       GPIO_PIN_7

// LCD Fonksiyonları
void LCD_Init(void);
void LCD_Clear(void);
void LCD_SetCursor(uint8_t row, uint8_t col);
void LCD_WriteChar(char c);
void LCD_WriteString(char* str);

#endif /* INC_LCD_H_ */
